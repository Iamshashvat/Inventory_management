import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
import math
import json
import csv

dataset_train = pd.read_csv('Book1.csv')
x_training_set = dataset_train.iloc[:, 1:4].values

y_training_set = dataset_train.iloc[:,-1:].values


sc = MinMaxScaler(feature_range = (0, 1))
x_training_set_scaled = sc.fit_transform(x_training_set)
y_training_set_scaled=sc.fit_transform(y_training_set)

X_train = []
y_train = []

X_train = np.array(x_training_set_scaled) 
y_train = np.array(y_training_set_scaled)

#adding the third dimension
X_train = np.reshape(X_train, (X_train.shape[0], X_train.shape[1], 1))



from keras.models import Sequential
from keras.layers import Dense
from keras.layers import LSTM
from keras.layers import Dropout

# Initialising the RNN
regressor = Sequential()

# Adding the first LSTM layer and some Dropout regularisation
regressor.add(LSTM(units = 50, return_sequences = True, input_shape = (X_train.shape[1], 1)))
#regressor.add(Dropout(0.2))

# Adding a second LSTM layer and some Dropout regularisation
regressor.add(LSTM(units = 50, return_sequences = True))
#regressor.add(Dropout(0.2))

# Adding a third LSTM layer and some Dropout regularisation
regressor.add(LSTM(units = 50, return_sequences = True))
#regressor.add(Dropout(0.2))

# Adding a fourth LSTM layer and some Dropout regularisation
regressor.add(LSTM(units = 50))
#regressor.add(Dropout(0.2))

# Adding the output layer
regressor.add(Dense(units = 1))

# Compiling the RNN
regressor.compile(optimizer = 'adam', loss = 'mean_squared_error')

# Fitting the RNN to the Training set
regressor.fit(X_train, y_train, epochs = 300, batch_size = 32)

# Getting the real stock price of 2017
dataset_test = pd.read_csv('Google_Stock_Price_Test.csv')
real_stock_price = dataset_test.iloc[:, 1:4].values


frames=[dataset_train,dataset_test]
total_dataset=pd.concat(frames)
total_dataset=total_dataset.drop(['Volume'],axis=1)
total_dataset=total_dataset.drop(['Date'],axis=1)

# Getting the predicted stock price of 2017
#dataset_total = pd.concat((dataset_train['Open'], dataset_test['Open']), axis = 2)
#inputs = dataset_total[len(dataset_total) - len(dataset_test) - 60:].values
inputs= total_dataset.values
#inputs = inputs.reshape(-1,1)
inputs = sc.transform(inputs)
X_test = []
#for i in range(60, 80):
 #   X_test.append(inputs[i-60:i, 0])

X_test = np.array(inputs)
#adding third dimension
X_test = np.reshape(X_test, (X_test.shape[0], X_test.shape[1], 1))
predicted_stock_price = regressor.predict(X_test)
predicted_stock_price = sc.inverse_transform(predicted_stock_price)

# Visualising the results
plt.plot(real_stock_price, color = 'red', label = 'Real Google Stock Price')
plt.plot(predicted_stock_price, color = 'blue', label = 'Predicted Google Stock Price')
plt.title('Google Stock Price Prediction')
plt.xlabel('Time')
plt.ylabel('Google Stock Price')
plt.legend()
plt.show()

def tojson():
    
    csvfile = open('Book1.csv', 'r')
    #jsonfile = open('file.json', 'w')
    fieldnames = ("Date","Open","High","Low","Volume")
    reader = csv.DictReader( csvfile, fieldnames)
    out = json.dumps( [ row for row in reader ] )
    return out
    #jsonfile.write(out)
    #jsonfile.close()
    #return jsonfile

tojson()
