<?php
//load_data.php
$connect = mysqli_connect("localhost", "root", "", "dell_10");
$output = '';
if(isset($_POST["brand_id"]))
{
     if($_POST["brand_id"] != '')
     {
          $sql = "SELECT * FROM product WHERE brand_id = '".$_POST["brand_id"]."'";
     }
     else
     {
          $sql = "SELECT * FROM product";
     }
     $result = mysqli_query($connect, $sql);
     while($row = mysqli_fetch_array($result))
     {
          $output .= '
          <div class="col-md-3">
          <div style="border:1px solid #ccc; padding:20px; margin-bottom:20px;">
          <form>
<img src="img_key.png" height="70px" width="70px">
   <input class="btn btn-primary btn-round" style="padding-left:10px;" type="button" onclick="incrementValue()" value="Increment Value" />

          '.$row["product_name"].'
          </form>
          </div>
          </div>
          ';
     }
     echo $output;
}
?>
